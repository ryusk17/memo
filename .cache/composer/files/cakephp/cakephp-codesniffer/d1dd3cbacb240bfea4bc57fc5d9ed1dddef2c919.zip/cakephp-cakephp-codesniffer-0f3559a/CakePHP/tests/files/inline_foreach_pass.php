<?php foreach ($somethings as $something): ?>
	<div>
		<p>Some blob of html</p>
	</div>
<?php endforeach; ?>
<div></div>
