source /usr/share/doc/fzf/examples/key-bindings.zsh

export FZF_DEFAULT_OPTS='--color=fg+:11 --height 70% --reverse --select-1 --exit-0 --multi' #https://www.rasukarusan.com/entry/2018/08/14/083000

