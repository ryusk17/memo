<?php

use Twig\Node\Expression\Test\SameasTest;

class_exists('Twig\Node\Expression\Test\SameasTest');

if (\false) {
    class Twig_Node_Expression_Test_Sameas extends SameasTest
    {
    }
}
