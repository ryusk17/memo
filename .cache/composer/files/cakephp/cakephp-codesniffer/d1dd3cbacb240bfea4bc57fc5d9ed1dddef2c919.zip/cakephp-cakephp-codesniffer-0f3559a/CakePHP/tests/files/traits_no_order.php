<?php

use One;
use Two;

class Foo {

	use LogTrait;
	use FirstTrait;

}