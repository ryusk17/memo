<?php
/**
 * Stub.
 *
 * @since 150424 Initial release.
 */
namespace WebSharks\CssMinifier;

require_once dirname(dirname(__FILE__)).'/vendor/autoload.php';
