<?php
/**
 * PHAR Stub.
 *
 * @since 150424 Initial release.
 */
namespace WebSharks\CssMinifier;

\Phar::mapPhar('websharks-css-minifier.phar');
require_once 'phar://websharks-css-minifier.phar/src/includes/stub.php';
__HALT_COMPILER();
