<?php
if ($value) {
	$thing = 'test';
	}
