<?php
if (isset($a)) {
	echo 'a isset';
} else if (isset($b)) {
	echo 'b isset';
}
