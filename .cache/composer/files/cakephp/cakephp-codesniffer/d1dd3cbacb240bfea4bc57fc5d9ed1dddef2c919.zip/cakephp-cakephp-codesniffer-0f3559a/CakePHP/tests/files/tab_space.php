<?php
$var	 = 'tab and space';