# README

最小限のドットファイル

以下構成でWSL2で動作確認済み
- git
- zsh
    - p10k
    - fzf
- vim
- config
