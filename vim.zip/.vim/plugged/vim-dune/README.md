# vim-dune
Syntax highlighting for `jbuild` files used by [dune](https://github.com/ocaml/dune) (previously *jbuilder*).

In the future, I hope to add support for running jbuilder directly from vim.

## Installation

If you are using pathogen, simply clone this repo into `~/.vim/bundle` as follows

```
    $ git clone https://github.com/figitaki/vim-dune ~/.vim/bundle/vim-dune
```

Currently I have no plans to add support for Neobundle etc. in the future, but PRs are welcome.
