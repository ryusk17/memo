Finder Component
================

The Finder component finds files and directories via an intuitive fluent
interface.

Resources
---------

  * [Documentation](https://symfony.com/doc/current/components/finder.html)
  * [Contributing](https://symfony.com/doc/current/contributing/index.html)
  * [Report issues](https://github.com/symfony/symfony/issues) and
    [send Pull Requests](https://github.com/symfony/symfony/pulls)
    in the [main Symfony repository](https://github.com/symfony/symfony)
