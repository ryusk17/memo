<?php

use Twig\Test\IntegrationTestCase;

class_exists('Twig\Test\IntegrationTestCase');

if (\false) {
    class Twig_Test_IntegrationTestCase extends IntegrationTestCase
    {
    }
}
