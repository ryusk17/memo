<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\InternalErrorException', 'Cake\Network\Exception\InternalErrorException');
deprecationWarning('Use Cake\Http\Exception\InternalErrorException instead of Cake\Network\Exception\InternalErrorException.');
