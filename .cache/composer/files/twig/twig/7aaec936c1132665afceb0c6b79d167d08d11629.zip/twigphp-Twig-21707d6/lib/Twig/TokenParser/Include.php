<?php

use Twig\TokenParser\IncludeTokenParser;

class_exists('Twig\TokenParser\IncludeTokenParser');

if (\false) {
    class Twig_TokenParser_Include extends IncludeTokenParser
    {
    }
}
