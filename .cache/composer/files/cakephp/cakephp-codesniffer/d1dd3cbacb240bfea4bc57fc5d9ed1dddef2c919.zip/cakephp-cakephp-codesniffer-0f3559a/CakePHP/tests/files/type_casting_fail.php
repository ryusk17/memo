<?php

$isActive = (boolean)$value;
$count = (integer)$someNumber;
