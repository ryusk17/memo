<?php
// @deprecated 3.4.0 Load new class and alias
class_exists('Cake\Http\Response');
deprecationWarning('Use Cake\Http\Response instead of Cake\Network\Response.');
