#!/bin/sh
vim -u NONE -i NONE -N -S macros/generate-ftplugins.vim -c quit
