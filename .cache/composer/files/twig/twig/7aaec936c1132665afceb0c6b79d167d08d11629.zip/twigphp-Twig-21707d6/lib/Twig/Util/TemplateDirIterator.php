<?php

use Twig\Util\TemplateDirIterator;

class_exists('Twig\Util\TemplateDirIterator');

if (\false) {
    class Twig_Util_TemplateDirIterator extends TemplateDirIterator
    {
    }
}
