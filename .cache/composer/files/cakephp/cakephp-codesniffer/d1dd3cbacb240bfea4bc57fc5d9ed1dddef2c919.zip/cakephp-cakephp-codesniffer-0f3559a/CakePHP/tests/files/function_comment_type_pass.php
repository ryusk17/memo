<?php

class Foo {

/**
 * Some sentence.
 *
 * @param int $param Some Param.
 * @param bool $otherParam Some Other Param.
 * @return string Something.
 */
	public function bar($param, $otherParam) {
	}

}
