Installation
============

The only officialy supported method of installing this plugin is via composer.

.. code::

    composer require josegonzalez/cakephp-upload

Enable plugin
-------------
Use the shell command to enable the plugin. Execute the following line:

.. code:: shell

   bin/cake plugin load Josegonzalez/Upload
