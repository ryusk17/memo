<?php
$var  = 'double space';
