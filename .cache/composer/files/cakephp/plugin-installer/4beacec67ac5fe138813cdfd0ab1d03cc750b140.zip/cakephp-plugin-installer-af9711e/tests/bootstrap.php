<?php

$loader = require __DIR__ . '/../vendor/autoload.php';
$loader->add('Cake\Test\TestCase\Composer', __DIR__ . 'TestCase');
