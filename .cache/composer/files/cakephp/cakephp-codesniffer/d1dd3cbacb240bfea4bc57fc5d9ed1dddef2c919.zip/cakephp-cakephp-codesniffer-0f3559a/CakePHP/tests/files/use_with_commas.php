<?php

use Cake\Routing\Router, Cake\Error;

class Foo {
}
