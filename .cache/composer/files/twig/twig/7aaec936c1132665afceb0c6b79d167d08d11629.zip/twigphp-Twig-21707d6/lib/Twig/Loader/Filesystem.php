<?php

use Twig\Loader\FilesystemLoader;

class_exists('Twig\Loader\FilesystemLoader');

if (\false) {
    class Twig_Loader_Filesystem extends FilesystemLoader
    {
    }
}
