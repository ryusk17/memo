<?php
if(isset($test)) {
	echo 'hello';
}
