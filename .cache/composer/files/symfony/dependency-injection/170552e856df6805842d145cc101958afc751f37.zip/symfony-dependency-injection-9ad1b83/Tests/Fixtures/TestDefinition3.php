<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures;

use Symfony\Component\DependencyInjection\Definition;

class TestDefinition3 extends Definition
{
}
