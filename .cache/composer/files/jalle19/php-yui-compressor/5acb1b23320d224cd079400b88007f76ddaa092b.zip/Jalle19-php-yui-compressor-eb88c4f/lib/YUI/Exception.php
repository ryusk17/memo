<?php

/**
 * Namespaced exception wrapper
 *
 * @author Sam stenvall <sam@supportersplace.com>
 * @copyright Copyright &copy; Sam Stenvall 2013-
 * @license http://www.opensource.org/licenses/bsd-license.php New BSD License
 */
namespace YUI;

class Exception extends \Exception {
    
}
