<?php
$var 	= 'space and tab';