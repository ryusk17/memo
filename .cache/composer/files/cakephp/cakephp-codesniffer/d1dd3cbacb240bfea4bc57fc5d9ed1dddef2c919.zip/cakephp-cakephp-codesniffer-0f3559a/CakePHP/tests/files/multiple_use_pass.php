<?php
use CakePHP\Test as Test;
use Testing\Ok;

class Foo {
}
