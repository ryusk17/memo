<?php

class NiceClass1 extends Object{
}

class NiceClass3
{
}
