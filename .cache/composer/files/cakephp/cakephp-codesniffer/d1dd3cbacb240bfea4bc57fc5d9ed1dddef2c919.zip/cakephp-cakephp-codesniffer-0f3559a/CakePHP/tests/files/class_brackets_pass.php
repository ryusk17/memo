<?php

class NiceClass1 extends Object {
}

class NiceClass2 implements Object {
}

class NiceClass2 implements Object1, Object2 {
}

class NiceClass3 {
}
