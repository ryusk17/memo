<?php
// @deprecated 3.4.0 Load new class and alias.
class_exists('Cake\Http\Client\Auth\Oauth');
deprecationWarning('Use Cake\Http\Client\Auth\Oauth instead of Cake\Network\Http\Auth\Oauth.');
