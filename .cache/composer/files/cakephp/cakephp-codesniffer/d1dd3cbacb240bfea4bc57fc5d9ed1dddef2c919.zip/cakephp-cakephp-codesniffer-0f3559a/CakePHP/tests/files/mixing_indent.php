<?php
if ($indented) {
	$var = array(
		 'space' => 'after 2 tabs'
	 );
}
