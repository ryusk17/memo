<?php

use Twig\Extension\DebugExtension;

class_exists('Twig\Extension\DebugExtension');

if (\false) {
    class Twig_Extension_Debug extends DebugExtension
    {
    }
}
