<?php
// @deprecated 3.4.0 Load new class and alias
class_exists('Cake\Http\ServerRequest');
deprecationWarning('Use Cake\Http\ServerRequest instead of Cake\Network\Request.');
