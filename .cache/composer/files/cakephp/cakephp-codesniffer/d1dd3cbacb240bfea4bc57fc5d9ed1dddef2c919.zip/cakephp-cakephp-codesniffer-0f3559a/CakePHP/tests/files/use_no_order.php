<?php

use Cake\Routing\Router;
use Cake\Error;
use Cake\Utility\Hash;

class Foo {
}
