<?php

class NiceClass3 implements Object, Object2
 {
}



