<?php

use Twig\Node\SetNode;

class_exists('Twig\Node\SetNode');

if (\false) {
    class Twig_Node_Set extends SetNode
    {
    }
}
