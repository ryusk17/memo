<?php

use Twig\Node\MacroNode;

class_exists('Twig\Node\MacroNode');

if (\false) {
    class Twig_Node_Macro extends MacroNode
    {
    }
}
