<?php

use Twig\Loader\SourceContextLoaderInterface;

class_exists('Twig\Loader\SourceContextLoaderInterface');

if (\false) {
    class Twig_SourceContextLoaderInterface extends SourceContextLoaderInterface
    {
    }
}
