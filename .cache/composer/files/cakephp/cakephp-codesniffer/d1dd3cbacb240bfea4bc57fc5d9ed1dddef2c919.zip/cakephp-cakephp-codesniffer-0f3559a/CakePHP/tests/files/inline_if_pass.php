<?php if ($something) : ?>
	<div>
		<p>Some blob of html</p>
	</div>
<?php endif; ?>
<?php if ($something) : ?>
	<?php if ($somethingElse) : ?>
		<p>Hi there!</p>
	<?php endif; ?>
<?php endif; ?>
<div></div>
