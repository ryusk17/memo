<?php

namespace Josegonzalez\Upload;

use Cake\Core\BasePlugin;

/**
 * Plugin class for CakePHP 3.6.0 plugin collection.
 */
class Plugin extends BasePlugin
{
}
