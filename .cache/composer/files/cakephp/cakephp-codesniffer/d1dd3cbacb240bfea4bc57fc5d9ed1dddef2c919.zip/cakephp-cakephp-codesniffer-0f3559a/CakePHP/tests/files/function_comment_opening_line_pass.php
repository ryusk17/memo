<?php

class Foo {

/**
 * Some sentence.
 *
 * @return void
 */
	public function bar() {
	}

}
