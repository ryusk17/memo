<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\Container;

class ConstructorWithoutArgumentsContainer
{
    public function __construct()
    {
    }
}
