<?php

use Twig\Node\Expression\Binary\MatchesBinary;

class_exists('Twig\Node\Expression\Binary\MatchesBinary');

if (\false) {
    class Twig_Node_Expression_Binary_Matches extends MatchesBinary
    {
    }
}
