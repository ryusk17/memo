<?php

use Twig\Node\DeprecatedNode;

class_exists('Twig\Node\DeprecatedNode');

if (\false) {
    class Twig_Node_Deprecated extends DeprecatedNode
    {
    }
}
