<?php
$noGood = empty ($thing);
$fail = include ('./inline_if_pass.php');
$o = $obj->something ('testing');
fail_whale ();
