<?php

class NiceClass3
{
}

class NiceClass1 extends Object {
}


