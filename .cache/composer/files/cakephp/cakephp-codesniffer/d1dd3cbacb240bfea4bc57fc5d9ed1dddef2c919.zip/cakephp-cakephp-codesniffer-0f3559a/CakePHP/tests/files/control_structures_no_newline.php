<?php
if ($condition)
{
	$thing = 'test';
}
