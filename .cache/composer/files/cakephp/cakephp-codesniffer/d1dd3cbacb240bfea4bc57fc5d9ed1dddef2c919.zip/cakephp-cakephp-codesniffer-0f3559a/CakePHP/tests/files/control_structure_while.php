<?php
while (false)
        echo 'false';

