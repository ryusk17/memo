<?php

use Twig\Extension\ExtensionInterface;

class_exists('Twig\Extension\ExtensionInterface');

if (\false) {
    class Twig_ExtensionInterface extends ExtensionInterface
    {
    }
}
