<?php
// @deprecated 3.6.0 Backwards compatibility alias
class_alias('Cake\Http\Session\CacheSession', 'Cake\Network\Session\CacheSession');
deprecationWarning('Use Cake\Http\Session\CacheSession instead of Cake\Network\Session\CacheSession.');
