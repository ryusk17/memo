<?php declare(strict_types=1);

namespace WyriHaximus\HtmlCompress;

use WyriHaximus\Compress\CompressorInterface;

interface HtmlCompressorInterface extends CompressorInterface
{
}
