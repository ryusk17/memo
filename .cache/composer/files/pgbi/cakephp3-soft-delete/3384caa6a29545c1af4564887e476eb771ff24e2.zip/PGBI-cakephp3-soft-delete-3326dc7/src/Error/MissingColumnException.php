<?php

namespace SoftDelete\Error;

use Cake\Core\Exception\Exception;

class MissingColumnException extends Exception
{
}