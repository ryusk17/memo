<?php

use Twig\Node\SetTempNode;

class_exists('Twig\Node\SetTempNode');

if (\false) {
    class Twig_Node_SetTemp extends SetTempNode
    {
    }
}
