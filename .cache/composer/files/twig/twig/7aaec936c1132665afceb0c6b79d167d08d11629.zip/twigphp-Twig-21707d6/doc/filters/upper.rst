``upper``
=========

The ``upper`` filter converts a value to uppercase:

.. code-block:: twig

    {{ 'welcome'|upper }}

    {# outputs 'WELCOME' #}
