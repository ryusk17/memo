<?php

class Foo {

/** 
 * There is a (disallowed) trailing space after the opening ** in this doc block.
 *
 * @return void
 */
	public function bar() {
	}

}
