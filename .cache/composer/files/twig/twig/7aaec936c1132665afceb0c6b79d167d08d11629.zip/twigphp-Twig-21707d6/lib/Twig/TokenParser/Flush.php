<?php

use Twig\TokenParser\FlushTokenParser;

class_exists('Twig\TokenParser\FlushTokenParser');

if (\false) {
    class Twig_TokenParser_Flush extends FlushTokenParser
    {
    }
}
