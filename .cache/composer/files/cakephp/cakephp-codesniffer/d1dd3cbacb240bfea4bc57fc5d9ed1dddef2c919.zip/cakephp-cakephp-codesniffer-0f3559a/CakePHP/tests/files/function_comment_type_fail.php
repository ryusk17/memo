<?php

class Foo {

/**
 * Some sentence.
 *
 * @param integer $param Some Param.
 * @param boolean $otherParam Some Other Param.
 * @return string Something.
 */
	public function bar($param, $otherParam) {
	}

}
