<?php

do
        echo 'dowhile test';
while (false);

