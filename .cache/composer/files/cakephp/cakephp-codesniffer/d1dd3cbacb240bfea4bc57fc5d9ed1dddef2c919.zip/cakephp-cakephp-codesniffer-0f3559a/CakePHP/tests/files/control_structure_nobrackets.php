<?php

if($abc == true)
        echo 'hello';
