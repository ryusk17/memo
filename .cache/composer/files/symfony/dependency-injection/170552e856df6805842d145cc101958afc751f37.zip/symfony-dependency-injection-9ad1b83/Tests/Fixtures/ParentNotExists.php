<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures;

class ParentNotExists extends \NotExists
{
}
