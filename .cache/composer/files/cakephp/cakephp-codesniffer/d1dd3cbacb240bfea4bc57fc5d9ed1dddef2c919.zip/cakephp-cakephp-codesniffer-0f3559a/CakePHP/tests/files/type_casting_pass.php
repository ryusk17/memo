<?php

$isActive = (bool)$value;
$count = (int)$someNumber;
