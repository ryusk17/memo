<?php

use Twig\Node\SpacelessNode;

class_exists('Twig\Node\SpacelessNode');

if (\false) {
    class Twig_Node_Spaceless extends SpacelessNode
    {
    }
}
