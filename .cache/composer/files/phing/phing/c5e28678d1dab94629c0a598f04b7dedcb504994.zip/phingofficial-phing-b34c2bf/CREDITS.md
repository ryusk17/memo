P     H     I     N     G
=========================


Phing 2.x Development
---------------------

  - Michiel Rook <mrook@php.net>
  - Hans Lellelid <hans@xmpl.org>
  - Sebastian Bergmann <sb@sebastian-bergmann.de>
  - Joakim Bodin <joakim.bodin+phing@gmail.com>
  - Johan Van den Brande <johan@vandenbrande.com>
  - Bryan Davis <bender@casadebender.com>
  - Andrew Eddie <andrew.eddie@jamboworks.com>
  - Markus Fischer <markus@fischer.name>
  - David Giffin <david@giffin.org>
  - Ryan Grove <ryan@wonko.com>
  - Frank Kleine <mikey@stubbles.net>
  - George Miroshnikov <laggy.luke@gmail.com>
  - David Persson <davidpersson at qeweurope dot org>
  - Stefan Priebsch <stefan.priebsch@e-novative.de>
  - Jorrit Schippers <jorrit at ncode dot nl>
  - Alexey Shockov <alexey@shockov.com>
  - Dirk Thomas <dirk.thomas@4wdmedia.de>
  - Knut Urdalen <knut.urdalen@gmail.com>
  - Mike Wittje <mw@mike.wittje.de>
  - Benjamin Schultz <bschultz@proqrent.de>
  - Andrei Serdeliuc <andrei@serdeliuc.ro>
  - Victor Farazdagi
  - Christian Weiske
  - Matthias Pigulla
  - Lineke Kerckhoffs-Willems <lineke@phpassionate.com>
  - Utsav Handa <handautsav@hotmail.com>
  - Ken Guest <ken@linux.ie>

  If you've done work on Phing and you are not listed here, please feel free
  to add yourself.

Original Phing 1.x Development
------------------------------

  - Andreas Aderhold <andi@binarycloud.com>
  - Alex Black <enigma@turingstudio.com>
  - Albert Lash <alash@plateauinnovation.com>
  - Charlie Killian <charlie@tizac.com>
  - Manuel Holtgrewe <grin@gmx.net>
  - Andrzej Nowodworski <a.nowodworski@learn.pl>
  - Jason Hines <jason@greenhell.com>
  - Jesse Estevez <jesseestevez@earthlink.net>
  - Andris Spruds <Andris.Spruds@stud.lba.lv>
  - Ronald TAO <ronaldtao@hotmail.com>
  - Yannick Lecaillez <yl@seasonfive.com>
  - Hans Lellelid <hans@xmpl.org>
